mod tcp_server;
use std::net::SocketAddr;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let socket_addr: SocketAddr = "127.0.0.1:5502".parse()?;

    println!("Starting Modbus TCP server");
    
    tcp_server::server_context(socket_addr).await?;

    Ok(())
}