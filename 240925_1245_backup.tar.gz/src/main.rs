// SPDX-FileCopyrightText: Copyright (c) 2017-2024 slowtec GmbH <post@slowtec.de>
// SPDX-License-Identifier: MIT OR Apache-2.0

//! # TCP server example
//!
//! This example shows how to start a server and implement basic register
//! read/write operations.
mod server;
mod client;
mod service;
mod config_load;
mod logger;

use std::net::SocketAddr;
use tokio::time::sleep;
use std::time::Duration;
use anyhow::Result;
use log::{info, error};

use server::run_modbus_server;
use client::test_modbus_server;
use config_load::load_config;
use logger::init_logger;

#[tokio::main]
async fn main() -> Result<()> {
    init_logger();

    info!("[MAIN   ] Starting application");
    let config = load_config("config/meter_config.yaml")?;
    let socket_addr: SocketAddr = format!("{}:{}", config.meter_data.ip, config.meter_data.port).parse()?;

    tokio::spawn(async move {
        if let Err(e) = run_modbus_server(socket_addr).await {
            error!("Server error: {}", e);
        }
    });

    sleep(Duration::from_secs(1)).await;
    test_modbus_server(socket_addr).await;

    info!("[MAIN   ] Application finished");
    Ok(())
}