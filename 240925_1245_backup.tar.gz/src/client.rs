use std::net::SocketAddr;
use std::time::Duration;
use tokio_modbus::prelude::*;
use log::{info, error, debug};

pub async fn test_modbus_server(socket_addr: SocketAddr) {
    tokio::join!(
        async {
            // Give the server some time for starting up
            tokio::time::sleep(Duration::from_secs(1)).await;

            info!("[TEST   ] Connecting client...");
            let mut ctx = match tcp::connect(socket_addr).await {
                Ok(ctx) => ctx,
                Err(e) => {
                    error!("[TEST   ] Failed to connect to server: {}", e);
                    return;
                }
            };

            debug!("[TEST   ] Reading 2 input registers...");
            match ctx.read_input_registers(0x00, 2).await {
                Ok(response) => {
                    info!("[TEST   ] Read input registers result: {:?}", response);
                    assert_eq!(response.unwrap(), vec![1234, 5678], "Unexpected input register values");
                },
                Err(e) => error!("[TEST   ] Failed to read input registers: {}", e),
            }

            debug!("[TEST   ] Writing 2 holding registers...");
            match ctx.write_multiple_registers(0x01, &[7777, 8888]).await {
                Ok(_) => info!("[TEST   ] Successfully wrote holding registers"),
                Err(e) => error!("[TEST   ] Failed to write holding registers: {}", e),
            }

            debug!("[TEST   ] Reading 4 holding registers...");
            match ctx.read_holding_registers(0x00, 4).await {
                Ok(response) => {
                    info!("[TEST   ] Read holding registers result: {:?}", response);
                    assert_eq!(response.unwrap(), vec![10, 7777, 8888, 40], "Unexpected holding register values");
                },
                Err(e) => error!("[TEST   ] Failed to read holding registers: {}", e),
            }

            debug!("[TEST   ] Reading nonexistent holding register address...");
            let response = ctx.read_holding_registers(0x100, 1).await.unwrap();
            info!("[TEST   ] The result is '{response:?}'");
            assert!(matches!(response, Err(Exception::IllegalDataAddress)));

            info!("[TEST   ] All tests completed.");
        },
        tokio::time::sleep(Duration::from_secs(5))
    );
}
