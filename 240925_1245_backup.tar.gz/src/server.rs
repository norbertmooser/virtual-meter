use std::net::SocketAddr;
use tokio::net::TcpListener;
use tokio_modbus::server::tcp::{accept_tcp_connection, Server};
use anyhow::Result;
use log::{info, error};

use crate::service::ExampleService;

pub async fn run_modbus_server(socket_addr: SocketAddr) -> Result<()> {
    info!("[SERVER ] Starting up server on {socket_addr}");
    let listener = TcpListener::bind(socket_addr).await?;
    info!("[SERVER ] Listener bound successfully");
    let server = Server::new(listener);
    info!("[SERVER ] Server created");
    
    let new_service = |socket_addr| {
        info!("[SERVER ] New service requested for {socket_addr}");
        Ok(Some(ExampleService::new()))
    };
    
    let on_connected = |stream, socket_addr| async move {
        info!("[SERVER ] New connection from {socket_addr}");
        accept_tcp_connection(stream, socket_addr, new_service)
    };
    
    let on_process_error = |err| {
        error!("[SERVER ] Process error: {err}");
    };
    
    info!("[SERVER ] Starting server...");
    server.serve(&on_connected, on_process_error).await?;
    info!("[SERVER ] Server stopped");
    Ok(())
}
